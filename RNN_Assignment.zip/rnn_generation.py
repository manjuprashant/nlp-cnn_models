import numpy as np
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, SimpleRNN, Dense
from tensorflow.keras.utils import to_categorical

with open("history_corpus.txt", "r") as f:
    corpus = f.read().lower()

tokenizer = Tokenizer()
tokenizer.fit_on_texts([corpus])
total_words = len(tokenizer.word_index) + 1
input_sequences = []

tokens = tokenizer.texts_to_sequences([corpus])[0]
for i in range(3, len(tokens)):
    input_sequences.append(tokens[i-3:i+1])

input_sequences = np.array(input_sequences)
X = input_sequences[:, :-1]
y = to_categorical(input_sequences[:, -1], num_classes=total_words)

model = Sequential([
    Embedding(total_words, 50, input_length=3),
    SimpleRNN(128),
    Dense(128, activation='relu'),
    Dense(total_words, activation='softmax')
])
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X, y, epochs=50, verbose=1)

seed_text = "the roman empire"
for _ in range(20):
    token_list = tokenizer.texts_to_sequences([seed_text])[0][-3:]
    token_list = pad_sequences([token_list], maxlen=3)
    predicted = model.predict(token_list, verbose=0)
    next_word = tokenizer.index_word[np.argmax(predicted)]
    seed_text += ' ' + next_word
print("Generated Text:\n", seed_text)
