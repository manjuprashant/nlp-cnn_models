# RNN Assignment: Text Classification and Next Word Generation

## Overview

This project demonstrates Recurrent Neural Networks (RNNs) for:

1. **Text Classification** – Classify snippets into: Math, Science, History, English.
2. **Next Word Generation** – Generate 20 words after a starting phrase using an educational corpus.

## Files

- `classification_dataset.csv` – Labeled snippets.
- `history_corpus.txt` – Educational corpus.
- `rnn_classification.py` – Classification RNN.
- `rnn_generation.py` – Text generation RNN.

## How to Run

```bash
pip install -r requirements.txt
python rnn_classification.py
python rnn_generation.py
```

## Example Output

### Classification Accuracy:
> Test Accuracy: ~ (depends on train-test split)

### Generated Text:
> the roman empire was one of the most powerful in the world and its legacy continues ...

